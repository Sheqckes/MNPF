<?php
session_start();

// Redirect to login if the user is not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
include 'db.php';

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role']; // 'client' or 'farmer'

// Fetch products
$products_query = $conn->query("SELECT * FROM products");
if (!$products_query) {
    die("Error fetching products: " . $conn->error);
}
$products = $products_query->fetch_all(MYSQLI_ASSOC);

// If the user is a farmer, fetch all orders
$orders = [];
if ($user_role === 'farmer') {
    $orders_query = $conn->query("SELECT o.id, o.client_name, o.product_id, o.quantity, 
                                         p.name AS product_name, (o.quantity * p.price) AS price
                                  FROM orders o
                                  JOIN products p ON o.product_id = p.id");
    if (!$orders_query) {
        die("Error fetching orders: " . $conn->error);
    }
    $orders = $orders_query->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($user_role) ?> Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        nav {
            margin-top: 15px;
            text-align: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            font-size: 16px;
            margin: 0 15px;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #45a049;
        }

        main {
            padding: 30px;
        }

        h2 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            justify-items: center;
        }

        .product {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 280px;
        }

        .product:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .product img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .product h3 {
            font-size: 20px;
            color: #333;
            margin: 15px 0;
        }

        .product p {
            font-size: 16px;
            color: #555;
            margin: 10px 0;
        }

        .product .price {
            font-size: 18px;
            color: #4CAF50;
            font-weight: bold;
        }

        footer {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: 40px;
        }

        footer a {
            color: white;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            nav a {
                margin: 5px;
                padding: 8px 15px;
            }

            .products {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 480px) {
            .products {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<header class="header">
    <h1>Welcome, <?= htmlspecialchars($user_role) ?></h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="products.php">Products</a>
        <?php if ($user_role === 'farmer'): ?>
            <a href="add_weather.php">Weather and Soil</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>

    <h1>Embrace Our Farm space</h1>

    <h2>Products Available</h2>
    <div class="products">
    <?php foreach ($products as $product): ?>
    <div class="product">
        <!-- Assuming each $product already has the required data -->
        <img src="<?= htmlspecialchars($product['image'] ?? 'uploads/default.jpg') ?>" alt="Product Image">
        <h3><?= htmlspecialchars($product['name']) ?></h3>
        <p><?= htmlspecialchars($product['description']) ?></p>
        <p class="price"><?= number_format($product['price'], 2) ?> KSH</p>
        <?php if ($user_role === 'client'): ?>
            <a href="order.php?product_id=<?= $product['id'] ?>">Place Order</a>
        <?php elseif ($user_role === 'farmer'): ?>
            <a href="edit_product.php?product_id=<?= $product['id'] ?>">Edit</a>
            <a href="delete_product.php?product_id=<?= $product['id'] ?>">Delete</a>
        <?php endif; ?>
    </div>
<?php endforeach; ?>

    </div>

    <?php if ($user_role === 'farmer'): ?>
        <h2>Orders</h2>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Client ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['id']) ?></td>
                        <td><?= htmlspecialchars($order['client_name']) ?></td>
                        <td><?= htmlspecialchars($order['product_name']) ?></td>
                        <td><?= htmlspecialchars($order['quantity']) ?></td>
                        <td><?= number_format($order['price'], 2) ?> KSH</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</main>

<footer>
<div>
            <h2>Contact Us</h2>
            <p>Email: <a href="mailto:support@farmmanagement.com">support@farmmanagement.com</a></p>
            <p>Phone: +2547 1386 3322</p>
        </div>
    <p>&copy; 2024 Farm Management System. All rights reserved. | <a href="contact.php">Contact</a></p>
</footer>

</body>
</html>
