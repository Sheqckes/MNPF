<?php
include 'db.php';

// Fetch the list of products
$result = $conn->query("SELECT * FROM products");

// Handle Add/Update/Delete product form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    $price = $_POST['price'] ?? null;
    $quantity = $_POST['quantity'] ?? null;

    // Handle file upload
    $image_path = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_name = basename($_FILES['image']['name']);
        // Save uploaded file in 'uploads' folder with a unique name
        $image_path = 'uploads/' . uniqid() . '-' . $image_name;
        move_uploaded_file($_FILES['image']['tmp_name'], $image_path);
    }

    // Add new product
    if (isset($_POST['add_product'])) {
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, quantity, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdis", $name, $description, $price, $quantity, $image_path);
        $stmt->execute();
        echo "<script>alert('Product added successfully!'); window.location.href = 'products.php';</script>";
    }

    // Update existing product
    elseif (isset($_POST['update_product'])) {
        $product_id = $_POST['product_id'];
        if ($image_path) {
            $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, quantity = ?, image = ? WHERE id = ?");
            $stmt->bind_param("ssdisi", $name, $description, $price, $quantity, $image_path, $product_id);
        } else {
            $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, quantity = ? WHERE id = ?");
            $stmt->bind_param("ssdi", $name, $description, $price, $quantity, $product_id);
        }
        $stmt->execute();
        echo "<script>alert('Product updated successfully!'); window.location.href = 'products.php';</script>";
    }

    // Delete a product
    elseif (isset($_POST['delete_product'])) {
        $product_id = $_POST['product_id'];
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        echo "<script>alert('Product deleted successfully!'); window.location.href = 'products.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 15px;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #4CAF50;
            color: white;
        }
        .form-container {
            width: 60%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        img {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<header>
    <h1>Farm Products</h1>
</header>

<div class="form-container">
    <h2>Add or Update Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="product_id" id="product_id">
        <label for="name">Product Name</label>
        <input type="text" name="name" id="name" required>

        <label for="description">Description</label>
        <input type="text" name="description" id="description" required>

        <label for="price">Price (KSH)</label>
        <input type="number" name="price" id="price" step="0.01" required>

        <label for="quantity">Quantity Available</label>
        <input type="number" name="quantity" id="quantity" required>

        <label for="image">Product Image</label>
        <input type="file" name="image" id="image" accept="image/*">

        <button type="submit" name="add_product">Add Product</button>
        <button type="submit" name="update_product" style="background-color: #ffa500;">Update Product</button>
    </form>
</div>

<h1>Available Products</h1>
<table>
    <thead>
        <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Description</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Order</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td>
                    <!-- Ensure that image is displayed properly -->
                    <img src="<?= htmlspecialchars($row['image'] ?? 'uploads/default.jpg') ?>" alt="Product Image">
                </td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= htmlspecialchars($row['price']) ?> KSH</td>
                <td><?= isset($row['quantity']) ? htmlspecialchars($row['quantity']) : 'N/A' ?></td>
                <td><a href="order.php?product_id=<?= $row['id'] ?>">Place Order</a></td>
                <td>
                    <button onclick="editProduct(<?= $row['id'] ?>, '<?= htmlspecialchars($row['name']) ?>', '<?= htmlspecialchars($row['description']) ?>', <?= $row['price'] ?>, <?= $row['quantity'] ?>)">Edit</button>
                </td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
                        <button type="submit" name="delete_product" style="background-color: red; color: white;">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<script>
    function editProduct(id, name, description, price, quantity) {
        document.getElementById('product_id').value = id;
        document.getElementById('name').value = name;
        document.getElementById('description').value = description;
        document.getElementById('price').value = price;
        document.getElementById('quantity').value = quantity;
    }
</script>

</body>
</html>
