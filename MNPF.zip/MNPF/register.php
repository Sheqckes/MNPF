<?php 
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $contact = htmlspecialchars($_POST['contact']);
    $role = htmlspecialchars($_POST['role']);

    // Insert user into the database
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, contact, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $email, $password, $contact, $role);

    if ($stmt->execute()) {
        if ($role === 'admin') {
            header("Location: admin_login.php?message=Registration successful! Please login as an admin.");
            exit;
        } else {
            $success_message = "Registration successful! You can now login.";
        }
    } else {
        $error_message = "Error occurred during registration.";
    }

    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: green;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #4CAF50; 
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        .logo {
            width: 100px;
            height: auto;
            margin-right: 20px;
        }
        .form-container h2 {
            text-align: center;
            color: #4CAF50;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .form-group button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            font-size: 16px;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #45a049;
        }
        .error, .success {
            color: #ff0000;
            text-align: center;
        }
        .login-container {
            text-align: center;
            margin-top: 20px;
        }
        .login-container a {
            color: #4CAF50;
            text-decoration: none;
        }
        .login-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header class="header">
    <h1>Farm Management System</h1>
</header>

<div class="container">
    <!-- Registration Form with Logo -->
    <div class="form-container">
        <div style="display: flex; justify-content: center; align-items: center;">
    
            <h2>Register</h2>
        </div>

        <?php if (isset($success_message)): ?>
            <p class="success"><?= htmlspecialchars($success_message) ?></p>
        <?php elseif (isset($error_message)): ?>
            <p class="error"><?= htmlspecialchars($error_message) ?></p>
        <?php endif; ?>

        <form action="register.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" placeholder="Enter Username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" name="email" id="email" placeholder="Enter email" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter Password" required>
            </div>
            <div class="form-group">
                <label for="contact">Contact</label>
                <input type="contact" name="contact" id="contact" placeholder="Enter contact" required>
            </div>

            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" required>
                    <option value="" disabled selected>Select Role</option>
                    <option value="farmer">Farmer</option>
                    <option value="client">Client</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <div class="form-group">
                <button type="submit">Register</button>
            </div>
        </form>

        <!-- Login and Admin Login Section -->
        <div class="login-container">
            <p>Already a member? <a href="login.php">Login</a></p>
            <p>Admin? <a href="admin_login.php">Admin Login</a></p>
        </div>
    </div>
</div>

</body>
</html>