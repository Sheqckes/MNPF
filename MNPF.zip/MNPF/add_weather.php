<?php
include 'db.php';

// Farmer's email address (you can fetch this dynamically based on a logged-in user)
$farmer_email = "farmer@example.com"; // Replace with dynamic email fetching logic

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $temperature = $_POST['temperature'];
    $humidity = $_POST['humidity'];
    $soil_moisture = $_POST['soil_moisture'];
    $rainfall = $_POST['rainfall'];
    $soil_ph = $_POST['soil_ph'];

    // Generate alert messages based on conditions
    $alert_message = "";
    if ($temperature < 15) {
        $alert_message .= "Low temperature detected. ";
    }
    if ($soil_moisture < 20) {
        $alert_message .= "Soil moisture is too low. ";
    }
    if ($temperature > 35) {
        $alert_message .= "High temperature detected. ";
    }
    if ($soil_ph < 5.5 || $soil_ph > 7.5) {
        $alert_message .= "Soil pH is not optimal. ";
    }

    // Save data to the database
    $stmt = $conn->prepare("INSERT INTO weather_soil_data (temperature, humidity, soil_moisture, rainfall, soil_ph, alert_message) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ddddds", $temperature, $humidity, $soil_moisture, $rainfall, $soil_ph, $alert_message);
    $stmt->execute();
    $stmt->close();

    // Send email notification if there's an alert
    if (!empty($alert_message)) {
        $subject = "Farm Alert: Immediate Attention Required!";
        $headers = "From: no-reply@farmmanagement.com" . "\r\n" .
                   "Reply-To: support@farmmanagement.com" . "\r\n" .
                   "Content-Type: text/plain; charset=UTF-8";
        $body = "Dear Farmer,\n\nThe following issues have been detected on your farm:\n\n" . $alert_message . 
                "\n\nPlease take the necessary actions.\n\nThank you,\nFarm Management System.";

        if (mail($farmer_email, $subject, $body, $headers)) {
            echo "<script>alert('Data added successfully, and an email alert was sent to the farmer.');</script>";
        } else {
            echo "<script>alert('Data added successfully, but email alert failed to send.');</script>";
        }
    } else {
        echo "<script>alert('Data added successfully.');</script>";
    }

    // Redirect back to avoid form resubmission
    header("Location: index.php");
    exit();
}

// Fetch the latest weather and soil data from the database
$latest_data = $conn->query("SELECT * FROM weather_soil_data ORDER BY date DESC LIMIT 1")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f3f3f3;
        }
        header {
            background-color: #4CAF50; /* Green */
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        footer {
            background-color: #4CAF50; /* Green */
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff; /* White */
            border: 2px solid #8B4513; /* Brown */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 20px;
        }
        .container h2 {
            color: #4CAF50; /* Green */
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="number"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #4CAF50; /* Green */
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }

        .alert {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #8B4513; /* Brown */
            background-color: #f9f1e7; /* Light beige */
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <header>
        <h1>Farm Management System</h1>
    </header>

    <div class="container">
        <h2>Weather and Soil Monitoring</h2>
        <form action="" method="POST">
            <label for="temperature">Temperature (°C):</label>
            <input type="number" id="temperature" name="temperature" step="0.1" required>

            <label for="humidity">Humidity (%):</label>
            <input type="number" id="humidity" name="humidity" step="0.1" required>

            <label for="soil_moisture">Soil Moisture (%):</label>
            <input type="number" id="soil_moisture" name="soil_moisture" step="0.1" required>

            <label for="rainfall">Rainfall (mm):</label>
            <input type="number" id="rainfall" name="rainfall" step="0.1" required>

            <label for="soil_ph">Soil pH:</label>
            <input type="number" id="soil_ph" name="soil_ph" step="0.1" required>

            <button type="submit">Submit Data</button>
        </form>

        <?php if ($latest_data): ?>
            <div class="alert">
                <h3>Latest Monitoring Data:</h3>
                <p><strong>Temperature:</strong> <?= htmlspecialchars($latest_data['temperature']) ?> °C</p>
                <p><strong>Humidity:</strong> <?= htmlspecialchars($latest_data['humidity']) ?> %</p>
                <p><strong>Soil Moisture:</strong> <?= htmlspecialchars($latest_data['soil_moisture']) ?> %</p>
                <p><strong>Rainfall:</strong> <?= htmlspecialchars($latest_data['rainfall']) ?> mm</p>
                <p><strong>Soil pH:</strong> <?= htmlspecialchars($latest_data['soil_ph']) ?></p>
                <p><strong>Alerts:</strong> <?= htmlspecialchars($latest_data['alert_message'] ?: 'No alerts') ?></p>
            </div>
        <?php else: ?>
            <p>No data available. Please add weather and soil data.</p>
        <?php endif; ?>
    </div>

    <footer>
        <p>&copy; 2024 Farm Management System | Designed with ❤️ in Green, Brown, and White</p>
    </footer>

</body>
</html>
