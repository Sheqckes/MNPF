<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    // Check if admin
    $admin_check = $conn->prepare("SELECT id, password FROM admin WHERE username = ?");
    $admin_check->bind_param("s", $username);
    $admin_check->execute();
    $admin_check->store_result();

    if ($admin_check->num_rows > 0) {
        $admin_check->bind_result($id, $hashed_password);
        $admin_check->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['admin_id'] = $id;
            header("Location: admin_dashboard.php");
            exit;
        }
    }

    // Check if user
    $user_check = $conn->prepare("SELECT id, role, password FROM users WHERE username = ?");
    $user_check->bind_param("s", $username);
    $user_check->execute();
    $user_check->store_result();

    if ($user_check->num_rows > 0) {
        $user_check->bind_result($id, $role, $hashed_password);
        $user_check->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_role'] = $role;
            header("Location: user_dashboard.php");
            exit;
        }
    }

    $error_message = "Invalid username or password.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: green;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
        }

        .login-box {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        .login-box img {
            width: 100px;
            margin-bottom: 20px;
        }

        .login-box h2 {
            color: #4CAF50;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-group label {
            font-weight: bold;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 5px;
            font-size: 16px;
        }

        .form-group input:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .form-group button {
            width: 100%;
            padding: 15px;
            border-radius: 5px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }

        .form-group button:hover {
            background-color: #45a049;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .login-footer {
            margin-top: 20px;
            font-size: 14px;
        }

        .login-footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .login-footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .login-box {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<header class="header">
    <h1>Farm Management System</h1>
</header>

<div class="login-container">
    <div class="login-box">
        <!-- Logo can be added here -->
    
        <h2>Login</h2>

        <?php if (isset($error_message)): ?>
            <div class="error-message"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Enter Username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter Password" required>
            </div>

            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>

        <div class="login-footer">
            <p>Don't have an account? <a href="register.php">Register</a></p>
            <p>Admin? <a href="admin_login.php">Login as Admin</a></p>
        </div>
    </div>
</div>

</body>
</html>
