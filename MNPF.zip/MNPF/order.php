<?php
session_start();
include 'db.php'; // Include your database connection file

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please log in first!'); window.location.href = 'login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id'];
// Fetch logged-in user details
$user = $conn->query("SELECT username, contact FROM users WHERE id = $user_id")->fetch_assoc();
if (!$user) {
    echo "<script>alert('User not found. Please log in.'); window.location.href = 'login.php';</script>";
    exit;
}

// Fetch order history for the logged-in user
$orders = $conn->query("
    SELECT 
        o.id, 
        u.username AS client_name, 
        u.contact AS client_contact, 
        p.name AS product_name, 
        o.quantity, 
        o.order_date, 
        o.status, 
        (o.quantity * p.price) AS total_price 
    FROM orders o 
    JOIN users u ON o.client_name = u.id 
    JOIN products p ON o.product_id = p.id 
    WHERE u.id = $user_id
    ORDER BY o.order_date DESC
");

// Handle order submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Check if the product exists and fetch its price
    $stmt = $conn->prepare("SELECT price FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if (!$product) {
        echo "<script>alert('Product not found. Please select a valid product.'); window.location.href = 'order.php';</script>";
        exit;
    }

    // Insert the order into the database
    $stmt = $conn->prepare("INSERT INTO orders (client_name, product_id, quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $user_id, $product_id, $quantity);
    $stmt->execute();

    echo "<script>alert('Order placed successfully!'); window.location.href = 'order.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #4CAF50;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .form-group button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            font-size: 16px;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
    <script>
        // Calculate total price dynamically
        function calculateTotalPrice() {
            const quantity = document.getElementById('quantity').value;
            const price = document.getElementById('product').selectedOptions[0].dataset.price;
            const totalPrice = document.getElementById('total_price');
            totalPrice.textContent = `Total Price: ${quantity * price || 0}`;
        }
    </script>
</head>
<body>
    <header>
        <h1>Order Page</h1>
    </header>
    <div class="container">
        <h2>Place Your Order</h2>
        <form method="POST">
            <div class="form-group">
                <label for="client_name">Client Name:</label>
                <input type="text" id="client_name" name="client_name" value="<?= htmlspecialchars($user['username']) ?>" readonly>
            </div>
            <div class="form-group">
                <label for="client_contact">Client Contact:</label>
                <input type="text" id="client_contact" name="client_contact" value="<?= htmlspecialchars($user['contact']) ?>" readonly>
            </div>
            <div class="form-group">
                <label for="product">Product:</label>
                <select id="product" name="product_id" onchange="calculateTotalPrice()" required>
                    <option value="" disabled selected>Select a product</option>
                    <?php
                    $products = $conn->query("SELECT id, name, price FROM products");
                    while ($product = $products->fetch_assoc()):
                    ?>
                        <option value="<?= $product['id'] ?>" data-price="<?= $product['price'] ?>">
                            <?= htmlspecialchars($product['name']) ?> (Price: <?= $product['price'] ?>)
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" oninput="calculateTotalPrice()" required>
            </div>
            <p id="total_price">Total Price: 0</p>
            <div class="form-group">
                <button type="submit">Place Order</button>
            </div>
        </form>

        <h2>Order History</h2>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Order Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['product_name']) ?></td>
                        <td><?= htmlspecialchars($order['quantity']) ?></td>
                        <td><?= htmlspecialchars($order['total_price']) ?></td>
                        <td><?= htmlspecialchars($order['order_date']) ?></td>
                        <td><?= htmlspecialchars($order['status']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
