<?php
include 'db.php';
$data = $conn->query("SELECT * FROM weather_soil_data ORDER BY date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather & Soil Data History</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <h1>Weather & Soil Data History</h1>
    </header>
    <main>
        <table>
            <tr>
                <th>Date</th>
                <th>Temperature (°C)</th>
                <th>Humidity (%)</th>
                <th>Soil Moisture (%)</th>
                <th>Rainfall (mm)</th>
                <th>Soil pH</th>
            </tr>
            <?php while ($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['date']) ?></td>
                    <td><?= htmlspecialchars($row['temperature']) ?></td>
                    <td><?= htmlspecialchars($row['humidity']) ?></td>
                    <td><?= htmlspecialchars($row['soil_moisture']) ?></td>
                    <td><?= htmlspecialchars($row['rainfall']) ?></td>
                    <td><?= htmlspecialchars($row['soil_ph']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </main>
</body>
</html>
