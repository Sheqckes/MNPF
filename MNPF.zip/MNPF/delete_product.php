<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM products WHERE id = $id");
    $product = $result->fetch_assoc();
    if (!$product) {
        die("Product not found!");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        $id = intval($_POST['id']);
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error = "Failed to delete the product.";
        }
    } else {
        header("Location: admin_dashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #d9534f;
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        header h1 {
            margin: 0;
        }

        main {
            padding: 30px;
            max-width: 600px;
            margin: auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-section h2 {
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-top: 15px;
        }

        .warning {
            color: red;
            font-size: 16px;
            margin-bottom: 20px;
        }

        input, button {
            width: 100%;
            margin-top: 8px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #d9534f;
            color: white;
            font-weight: bold;
            border: none;
            margin-top: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #c9302c;
        }

        footer {
            background-color: #d9534f;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 40px;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('deleteForm');
            form.addEventListener('submit', (event) => {
                const confirmDelete = confirm('Are you sure you want to delete this product?');
                if (!confirmDelete) {
                    event.preventDefault();
                }
            });
        });
    </script>
</head>
<body>
    <header class="header">
        <h1>Delete Product</h1>
    </header>
    <main>
        <section class="form-section">
            <h2>Are you sure you want to delete this product?</h2>
            <?php if (isset($error)): ?>
                <p class="warning"><?= $error ?></p>
            <?php endif; ?>
            <form id="deleteForm" action="delete_product.php" method="POST">
                <input type="hidden" name="id" value="<?= htmlspecialchars($product['id'] ?? '') ?>">
                <p><strong>Product Name:</strong> <?= htmlspecialchars($product['name'] ?? 'Unknown') ?></p>
                <p><strong>Description:</strong> <?= htmlspecialchars($product['description'] ?? 'No description') ?></p>
                <p><strong>Price:</strong> Ksh<?= htmlspecialchars($product['price'] ?? '0.00') ?></p>
                <p><strong>Quantity:</strong> <?= htmlspecialchars($product['quantity'] ?? '0') ?></p>
                <input type="hidden" name="confirm" value="yes">
                <button type="submit">Confirm Delete</button>
            </form>
            <form action="admin_dashboard.php" method="GET">
                <button type="submit" style="background-color: #5bc0de;">Cancel</button>
            </form>
        </section>
    </main>
    <footer>
        <p>&copy; <?= date('Y') ?> Product Management System</p>
    </footer>
</body>
</html>

