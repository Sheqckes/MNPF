<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM products WHERE id = $id");
    $product = $result->fetch_assoc();
    if (!$product) {
        die("Product not found!");
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $name = htmlspecialchars($_POST['name']);
    $description = htmlspecialchars($_POST['description']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, quantity = ? WHERE id = ?");
    $stmt->bind_param("ssdii", $name, $description, $price, $quantity, $id);
    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "Failed to update the product.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        header h1 {
            margin: 0;
        }

        main {
            padding: 30px;
            max-width: 600px;
            margin: auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-section h2 {
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-top: 15px;
        }

        input, textarea, button {
            width: 100%;
            margin-top: 8px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            border: none;
            margin-top: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 20px;
        }

        footer {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 40px;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('editForm');
            form.addEventListener('submit', (event) => {
                const price = parseFloat(document.getElementById('price').value);
                const quantity = parseInt(document.getElementById('quantity').value);

                if (price < 0 || quantity < 0) {
                    alert('Price and Quantity must be non-negative.');
                    event.preventDefault();
                }
            });
        });
    </script>
</head>
<body>
    <header class="header">
        <h1>Edit Product</h1>
    </header>
    <main>
        <section class="form-section">
            <h2>Update Product Details</h2>
            <?php if (isset($error)): ?>
                <p class="error"><?= $error ?></p>
            <?php endif; ?>
            <form id="editForm" action="edit_product.php" method="POST">
    <input type="hidden" name="id" value="<?= htmlspecialchars($product['id'] ?? '') ?>">
    
    <label for="name">Product Name</label>
    <input type="text" id="name" name="name" value="<?= htmlspecialchars($product['name'] ?? '') ?>" required>
    
    <label for="description">Description</label>
    <textarea id="description" name="description" required><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
    
    <label for="price">Price (Ksh)</label>
    <input type="number" id="price" name="price" step="0.01" value="<?= htmlspecialchars($product['price'] ?? '') ?>" required>
    
    <label for="quantity">Quantity</label>
    <input type="number" id="quantity" name="quantity" value="<?= htmlspecialchars($product['quantity'] ?? '') ?>" required>
    
    <button type="submit">Update Product</button>
</form>

        </section>
    </main>
    <footer>
        <p>&copy; <?= date('Y') ?> Product Management System</p>
    </footer>
</body>
</html>
