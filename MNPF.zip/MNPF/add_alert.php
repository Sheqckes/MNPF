<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = htmlspecialchars($_POST['message']);
    $stmt = $conn->prepare("INSERT INTO alerts (message) VALUES (?)");
    $stmt->bind_param("s", $message);
    $stmt->execute();
    header("Location: admin_dashboard.php");
}
?>

<!-- Form -->
<form action="add_alert.php" method="POST">
    <textarea name="message" placeholder="Alert Message" required></textarea>
    <button type="submit">Add Alert</button>
</form>
