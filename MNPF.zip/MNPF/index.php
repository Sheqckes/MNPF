<?php
include 'db.php';
session_start();

// Check if the user is logged in
$user_logged_in = isset($_SESSION['user_id']);
$admin_logged_in = isset($_SESSION['admin_id']);

// Fetch the latest weather and soil data
$latest_data = $conn->query("SELECT * FROM weather_soil_data ORDER BY date DESC LIMIT 1")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm Management System</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #4CAF50;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            font-size: 32px;
        }

        .auth-links {
            text-align: center;
            margin-top: 10px;
        }

        .auth-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            margin: 0 10px;
        }

        .auth-links a:hover {
            text-decoration: underline;
        }

        nav.navbar {
            background-color: #333;
            padding: 10px 0;
            text-align: center;
        }

        nav.navbar ul {
            list-style-type: none;
            padding: 0;
        }

        nav.navbar li {
            display: inline;
            margin: 0 15px;
        }

        nav.navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        nav.navbar a:hover {
            color: #4CAF50;
        }

        main {
            padding: 30px;
            text-align: center;
        }

        .welcome h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        .welcome p {
            font-size: 18px;
            color: #555;
        }

        .latest-data, .card-container {
            margin-top: 30px;
        }

        .card-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 280px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card h3 {
            color: #4CAF50;
            font-size: 24px;
            margin-bottom: 15px;
        }

        .card p {
            color: #555;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .latest-data ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        .latest-data ul li {
            margin: 10px 0;
        }

        footer {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 40px;
        }

        footer p {
            font-size: 16px;
        }

        footer a {
            color: white;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            nav.navbar a {
                font-size: 16px;
            }

            .card-container {
                flex-direction: column;
                align-items: center;
            }

            .welcome h2 {
                font-size: 24px;
            }

            .welcome p {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

    <!-- Header Section -->
    <header class="header">
        <h1>Farm Management System</h1>
        <div class="auth-links">
            <?php if ($admin_logged_in): ?>
                <a href="admin_dashboard.php">Admin Dashboard</a> | <a href="logout.php">Logout</a>
            <?php elseif ($user_logged_in): ?>
                <a href="user_dashboard.php">Dashboard</a> | <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a> | <a href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="navbar">
        <ul>
            <li><a href="add_weather.php">Monitor Weather & Soil</a></li>
            <li><a href="products.php">View Products</a></li>
            <li><a href="order.php">Place Order</a></li>
            <li><a href="history.php">Data History</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <main>
        <section class="welcome">
            <h2>Welcome to the Farm Management System</h2>
            <p>Empowering farmers with tools for efficient farm management, monitoring resources, and maximizing productivity.</p>
        </section>

        <!-- Weather & Soil Monitoring Card -->
        <div class="card-container">
            <div class="card">
                <h3>Weather Monitoring</h3>
                <p>Monitor weather and soil conditions to make data-driven decisions.</p>
                <a href="add_weather.php" class="btn">View Weather Data</a>
            </div>
        </div>
        <div class="col-md-4 mb-4">
                <div class="card bg-light">
                    <div class="card-body">
                        <h2 class="card-title">Products</h2>
                        <p class="card-text">Monitor livestock and crops, produced in the farm and manage resources.</p>
                        <a href="products.php" class="btn btn-success">Explore Livestock</a>
                    </div>
                </div>
            </div>
        <!-- Weather and Soil Summary -->
        <section class="latest-data">
            <h3>Latest Weather & Soil Data</h3>
            <?php if ($latest_data): ?>
                <ul>
                    <li><strong>Date:</strong> <?= htmlspecialchars($latest_data['date']) ?></li>
                    <li><strong>Temperature:</strong> <?= htmlspecialchars($latest_data['temperature']) ?> °C</li>
                    <li><strong>Humidity:</strong> <?= htmlspecialchars($latest_data['humidity']) ?>%</li>
                    <li><strong>Soil Moisture:</strong> <?= htmlspecialchars($latest_data['soil_moisture']) ?>%</li>
                    <li><strong>Rainfall:</strong> <?= htmlspecialchars($latest_data['rainfall']) ?> mm</li>
                    <li><strong>Soil pH:</strong> <?= htmlspecialchars($latest_data['soil_ph']) ?></li>
                </ul>
            <?php else: ?>
                <p>No data available. Add weather and soil data to get started.</p>
            <?php endif; ?>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <div>
            <h2>Contact Us</h2>
            <p>Email: <a href="mailto:support@farmmanagement.com">support@farmmanagement.com</a></p>
            <p>Phone: +2547 1386 3322</p>
        </div>
        <p>&copy; 2024 Farm Management System | Designed with ❤️ in Green, Brown, and White</p>
    </footer>

</body>
</html>
