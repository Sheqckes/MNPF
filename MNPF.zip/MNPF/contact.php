<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // For Composer

function sendMail($recipientEmail, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'Jwinniesekinah@gmail.com'; // Replace with your email
        $mail->Password = 'Redstar1*'; // Replace with your email password or app-specific password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Encryption type
        $mail->Port = 587; // Port number for TLS

        // Email settings
        $mail->setFrom('Jwinnieshekinah@gmail.com', 'Farm Management System');
        $mail->addAddress($recipientEmail); // Add recipient email
        $mail->Subject = $subject;
        $mail->Body = $body;

        // Send the email
        $mail->send();
        echo "Email sent successfully!";
    } catch (Exception $e) {
        echo "Email could not be sent. Error: {$mail->ErrorInfo}";
    }
}

// Handling contact form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'db.php';

    // Sanitize input
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Insert contact form data into database
    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);
    $stmt->execute();
    $stmt->close();

    // Send a confirmation email to the user (sender)
    $subject = "Thank you for contacting us!";
    $body = "Dear $name,\n\nThank you for reaching out to us. We have received your message and will get back to you soon.\n\nMessage: $message";
    sendMail($email, $subject, $body); // Send to the user

    // Optionally, send an alert to the admin
    $adminSubject = "New Contact Message Received";
    $adminBody = "You have received a new message from $name.\n\nMessage: $message";
    sendMail('admin@example.com', $adminSubject, $adminBody); // Send to the admin

    // Display a success message
    echo "Thank you for reaching out! We'll get back to you soon.";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        main {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            color: #4CAF50;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        textarea:focus {
            border-color: #4CAF50;
            outline: none;
        }

        button {
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Responsive Design */
        @media screen and (max-width: 768px) {
            main {
                width: 90%;
                padding: 15px;
            }

            h1 {
                font-size: 24px;
            }

            input[type="text"],
            input[type="email"],
            textarea {
                font-size: 14px;
            }

            button {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <header>
        <h1>Contact Us</h1>
    </header>

    <main>
        <?php if (isset($success_message)): ?>
            <p><?= $success_message ?></p>
        <?php else: ?>
            <form action="contact.php" method="POST">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" placeholder="Your Message" rows="6" required></textarea>
                <button type="submit">Submit</button>
            </form>
        <?php endif; ?>
    </main>

</body>
</html>
