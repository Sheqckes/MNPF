<?php
// Farmer's email
$to = "farmer_email.com"; // Replace with the farmer's actual email

// Email subject and message
$subject = "Farm Alert: Immediate Attention Required!";
$message = "Dear Farmer,\n\nThe following issues have been detected on your farm:\n- Low temperature\n- Low soil moisture.\n\nPlease take action immediately.\n\nThank you,\nFarm Management System.";

// Email headers
$headers = "From: Jwinnieshekinah@gmail.com\r\n" .
           "Reply-To:farmer_email.com\r\n" .
           "X-Mailer: PHP/" . phpversion();

// Send the email
if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully to the farmer!";
} else {
    echo "Failed to send email. Check your configuration.";
}
?>
